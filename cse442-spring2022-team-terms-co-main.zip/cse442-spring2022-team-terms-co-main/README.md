**To Do Bot:**

This bot allows our users to have a friend that helps them organize their tasks. The bot has a natural lanuage API where we allow our users to:

_1) Add a task_\
        - Example: "remind me to sleep at 10:00 pm" or "remind me to run at 6pm". This task gets assigned a taskID which the user is informed of and can double check at any time by typing 'view'. 
        
        - Example: "remind me to sleep"        
        
                        > the bot will ask at what time
                        
                   provide time 

_2) Delete a task_\
        - "delete 1" of the format keyword delete followed by taskID

_3) Edit existing tasks_\
        - edit a task by typing "edit task_ID : new_task task_time" for example "edit 1: remind me to sleep at 9 pm"

_4) Check all completed tasks_\
        - type "completed 1" where 1 is the taskID which can be viewed using "view"

_5) View all tasks_\
        - type "view" to view all tasks and their IDs

_6) Ask for help with commands_\
        - type "help" for assistance with commands

We hope to make the lives of our users easier with the convenience of our very own toDoBot!
