from flask import Flask, redirect, render_template, request
from threading import Thread

app = Flask(__name__, template_folder='static')

@app.route('/', methods=['GET'])
def main():
    return render_template("index.html")

def run():
   app.run(host='0.0.0.0', port=8000)

def keep_alive():
    server = Thread(target=run)
    server.start()

# @app.route('/tasks', methods=['GET', 'POST'])
# def main():
#     if request.method  == 'POST':
        
#         return render_template("tasks.html")
    
#     upcoming  = user_dict
#     overdue   = user_dict_overdue
#     completed = user_dict_completed
    
#     return render_template("tasks.html",upcoming=upcoming,ovedue=overdue,completed=completed)


# if __name__ == '__main__':
#    app.run(host='0.0.0.0', port=8089, debug=True)
