function mbs(){
    getElementById("myData")
    console.log("ENTERED THE SCRIPT")
    //https://howtocreateapps.com/fetch-and-display-json-html-javascript/
    fetch('user_data.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            appendData(data);
        })
        .catch(function (err) {
            console.log('error: ' + err);
        });
    function appendData(data) {
        var mainContainer = document.getElementById("myData");
        console.log("Entered append data");
        console.log("DATA: " + data)
        console.log("Entries: " + Object.entries(data))
        
        for (let [key, value] of Object.entries(data)) {
            console.log(key);
            console.log(Object.entries(value))
            var div = document.createElement("div");
            div.innerHTML = 'Key: ' + key + " Values: " + Object.entries(value)
            mainContainer.appendChild(div);
            
        }
    }
}

function new_task(){
    
}